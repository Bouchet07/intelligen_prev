# intelligen
This is a Python package for math and artificial intelligence tools

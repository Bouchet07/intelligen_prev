import numpy as np

def prueba(n):
    print(np.linspace(0, n, 10))